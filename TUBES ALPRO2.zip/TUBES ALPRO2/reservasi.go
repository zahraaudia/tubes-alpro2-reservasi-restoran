package main
import "fmt"

const NMAX = 100

type Meja struct {
	nomor     int
	kapasitas int
	status    string
}

var dataMeja [NMAX]Meja
var n int

func inputMeja() {
	fmt.Print("Masukkan jumlah meja: ")
	fmt.Scan(&n)

	for i := 0; i < n; i++ {
		fmt.Println("\nMeja ke-", i+1)
		fmt.Print("Nomor meja: ")
		fmt.Scan(&dataMeja[i].nomor)
		fmt.Print("Kapasitas: ")
		fmt.Scan(&dataMeja[i].kapasitas)
		dataMeja[i].status = "Kosong"
	}
}

func tampilMeja() {
	fmt.Println("\nDaftar Meja:")
	for i := 0; i < n; i++ {
		fmt.Println("Meja", dataMeja[i].nomor,
			"| Kapasitas:", dataMeja[i].kapasitas,
			"| Status:", dataMeja[i].status)
	}
}

func tampilKosong() {
	fmt.Println("\nMeja Kosong:")
	for i := 0; i < n; i++ {
		if dataMeja[i].status == "Kosong" {
			fmt.Println("Meja", dataMeja[i].nomor,
				"| Kapasitas:", dataMeja[i].kapasitas)
		}
	}
}

func cariNomor() {
	var nomor int
	fmt.Print("Masukkan nomor meja: ")
	fmt.Scan(&nomor)

	for i := 0; i < n; i++ {
		if dataMeja[i].nomor == nomor {
			fmt.Println("Ditemukan:",
				"Meja", dataMeja[i].nomor,
				"| Kapasitas:", dataMeja[i].kapasitas,
				"| Status:", dataMeja[i].status)
			return
		}
	}
	fmt.Println("Tidak ditemukan")
}

func cariKapasitas() {
	var kap int
	fmt.Print("Masukkan kapasitas: ")
	fmt.Scan(&kap)

	var ketemu bool = false

	for i := 0; i < n; i++ {
		if dataMeja[i].kapasitas >= kap && dataMeja[i].status == "Kosong" {
			fmt.Println("Meja", dataMeja[i].nomor,
				"| Kapasitas:", dataMeja[i].kapasitas)
			ketemu = true
		}
	}

	if !ketemu {
		fmt.Println("Tidak ada meja tersedia")
	}
}

func urutkan() {
	var temp Meja

	for i := 0; i < n-1; i++ {
		min := i
		for j := i + 1; j < n; j++ {
			if dataMeja[j].kapasitas < dataMeja[min].kapasitas {
				min = j
			}
		}
		temp = dataMeja[i]
		dataMeja[i] = dataMeja[min]
		dataMeja[min] = temp
	}

	fmt.Println("Data berhasil diurutkan")
}

func reservasi() {
	var nomor int
	fmt.Print("Masukkan nomor meja: ")
	fmt.Scan(&nomor)

	for i := 0; i < n; i++ {
		if dataMeja[i].nomor == nomor {
			if dataMeja[i].status == "Kosong" {
				dataMeja[i].status = "Terisi"
				fmt.Println("Reservasi berhasil")
			} else {
				fmt.Println("Meja sudah terisi")
			}
			return
		}
	}
	fmt.Println("Meja tidak ditemukan")
}


func batal() {
	var nomor int
	fmt.Print("Masukkan nomor meja: ")
	fmt.Scan(&nomor)

	for i := 0; i < n; i++ {
		if dataMeja[i].nomor == nomor {
			if dataMeja[i].status == "Terisi" {
				dataMeja[i].status = "Kosong"
				fmt.Println("Reservasi dibatalkan")
			} else {
				fmt.Println("Meja sudah kosong")
			}
			return
		}
	}
	fmt.Println("Meja tidak ditemukan")
}


func menu() {
	var pilih int

	for {
		fmt.Println("\n=== MENU ===")
		fmt.Println("1. Input Meja")
		fmt.Println("2. Tampilkan Semua")
		fmt.Println("3. Cari Nomor")
		fmt.Println("4. Cari Kapasitas")
		fmt.Println("5. Tampilkan Kosong")
		fmt.Println("6. Urutkan")
		fmt.Println("7. Reservasi")
		fmt.Println("8. Batal Reservasi")
		fmt.Println("9. Keluar")

		fmt.Print("Pilih: ")
		fmt.Scan(&pilih)

		switch pilih {
		case 1:
			inputMeja()
		case 2:
			tampilMeja()
		case 3:
			cariNomor()
		case 4:
			cariKapasitas()
		case 5:
			tampilKosong()
		case 6:
			urutkan()
		case 7:
			reservasi()
		case 8:
			batal()
		case 9:
			fmt.Println("Selesai")
			return
		default:
			fmt.Println("Pilihan salah")
		}
	}
}

func main() {
	menu()
}