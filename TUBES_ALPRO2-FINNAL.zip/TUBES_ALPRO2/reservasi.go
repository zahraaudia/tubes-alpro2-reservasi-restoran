package main

import "fmt"

const NMAX = 100

type Meja struct {
	nomor     int
	kapasitas int
	status    string
}

var dataMeja [NMAX]Meja
var n int

func inputMeja() {
	fmt.Print("Masukkan jumlah meja: ")
	fmt.Scan(&n)

	for i := 0; i < n; i++ {
		fmt.Println("\nMeja ke-", i+1)

		fmt.Print("Nomor meja: ")
		fmt.Scan(&dataMeja[i].nomor)

		fmt.Print("Kapasitas: ")
		fmt.Scan(&dataMeja[i].kapasitas)

		dataMeja[i].status = "Kosong"
	}
}

func tampilMeja() {
	fmt.Println("\n=== DAFTAR MEJA ===")

	for i := 0; i < n; i++ {
		fmt.Println("Meja", dataMeja[i].nomor,
			"| Kapasitas:", dataMeja[i].kapasitas,
			"| Status:", dataMeja[i].status)
	}
}

func tampilKosong() {
	fmt.Println("\n=== MEJA KOSONG ===")

	for i := 0; i < n; i++ {
		if dataMeja[i].status == "Kosong" {
			fmt.Println("Meja", dataMeja[i].nomor,
				"| Kapasitas:", dataMeja[i].kapasitas)
		}
	}
}

func selectionSortAsc() {
	var temp Meja

	for i := 0; i < n-1; i++ {
		min := i

		for j := i + 1; j < n; j++ {
			if dataMeja[j].kapasitas < dataMeja[min].kapasitas {
				min = j
			}
		}

		temp = dataMeja[i]
		dataMeja[i] = dataMeja[min]
		dataMeja[min] = temp
	}

	fmt.Println("Data berhasil diurutkan Ascending")
}

func insertionSortDesc() {
	var temp Meja
	var j int

	for i := 1; i < n; i++ {
		temp = dataMeja[i]
		j = i - 1

		for j >= 0 && dataMeja[j].kapasitas < temp.kapasitas {
			dataMeja[j+1] = dataMeja[j]
			j--
		}

		dataMeja[j+1] = temp
	}

	fmt.Println("Data berhasil diurutkan Descending")
}

func sortNomorAsc() {
	var temp Meja

	for i := 0; i < n-1; i++ {
		min := i

		for j := i + 1; j < n; j++ {
			if dataMeja[j].nomor < dataMeja[min].nomor {
				min = j
			}
		}

		temp = dataMeja[i]
		dataMeja[i] = dataMeja[min]
		dataMeja[min] = temp
	}
}

func binarySearchNomor(nomor int) int {
	left := 0
	right := n - 1

	for left <= right {
		mid := (left + right) / 2

		if dataMeja[mid].nomor == nomor {
			return mid
		} else if nomor < dataMeja[mid].nomor {
			right = mid - 1
		} else {
			left = mid + 1
		}
	}

	return -1
}

func cariNomor() {
	var nomor int

	sortNomorAsc()

	fmt.Print("Masukkan nomor meja: ")
	fmt.Scan(&nomor)

	idx := binarySearchNomor(nomor)

	if idx != -1 {
		fmt.Println("Ditemukan:")
		fmt.Println("Meja", dataMeja[idx].nomor,
			"| Kapasitas:", dataMeja[idx].kapasitas,
			"| Status:", dataMeja[idx].status)
	} else {
		fmt.Println("Meja tidak ditemukan")
	}
}

func cariStatus() {
	var status string
	var ketemu bool = false

	fmt.Print("Masukkan status (Kosong/Terisi): ")
	fmt.Scan(&status)

	for i := 0; i < n; i++ {
		if dataMeja[i].status == status {
			fmt.Println("Meja", dataMeja[i].nomor,
				"| Kapasitas:", dataMeja[i].kapasitas)
			ketemu = true
		}
	}

	if !ketemu {
		fmt.Println("Data tidak ditemukan")
	}
}

func cariKapasitas() {
	var kap int
	var ketemu bool = false

	fmt.Print("Masukkan kapasitas: ")
	fmt.Scan(&kap)

	for i := 0; i < n; i++ {
		if dataMeja[i].kapasitas >= kap &&
			dataMeja[i].status == "Kosong" {

			fmt.Println("Meja", dataMeja[i].nomor,
				"| Kapasitas:", dataMeja[i].kapasitas)

			ketemu = true
		}
	}

	if !ketemu {
		fmt.Println("Tidak ada meja tersedia")
	}
}

func reservasi() {
	var nomor int

	fmt.Print("Masukkan nomor meja: ")
	fmt.Scan(&nomor)

	for i := 0; i < n; i++ {
		if dataMeja[i].nomor == nomor {

			if dataMeja[i].status == "Kosong" {
				dataMeja[i].status = "Terisi"
				fmt.Println("Reservasi berhasil")
			} else {
				fmt.Println("Meja sudah terisi")
			}

			return
		}
	}

	fmt.Println("Meja tidak ditemukan")
}

func batal() {
	var nomor int

	fmt.Print("Masukkan nomor meja: ")
	fmt.Scan(&nomor)

	for i := 0; i < n; i++ {
		if dataMeja[i].nomor == nomor {

			if dataMeja[i].status == "Terisi" {
				dataMeja[i].status = "Kosong"
				fmt.Println("Reservasi dibatalkan")
			} else {
				fmt.Println("Meja sudah kosong")
			}

			return
		}
	}

	fmt.Println("Meja tidak ditemukan")
}

func menu() {
	var pilih int

	for {
		fmt.Println("\n===== MENU =====")
		fmt.Println("1.  Input Meja")
		fmt.Println("2.  Tampilkan Semua")
		fmt.Println("3.  Cari Nomor Meja (Binary Search)")
		fmt.Println("4.  Cari Kapasitas")
		fmt.Println("5.  Cari Status (Sequential Search)")
		fmt.Println("6.  Tampilkan Meja Kosong")
		fmt.Println("7.  Urutkan Ascending (Selection Sort)")
		fmt.Println("8.  Urutkan Descending (Insertion Sort)")
		fmt.Println("9.  Reservasi")
		fmt.Println("10. Batal Reservasi")
		fmt.Println("11. Keluar")

		fmt.Print("Pilih: ")
		fmt.Scan(&pilih)

		switch pilih {

		case 1:
			inputMeja()

		case 2:
			tampilMeja()

		case 3:
			cariNomor()

		case 4:
			cariKapasitas()

		case 5:
			cariStatus()

		case 6:
			tampilKosong()

		case 7:
			selectionSortAsc()

		case 8:
			insertionSortDesc()

		case 9:
			reservasi()

		case 10:
			batal()

		case 11:
			fmt.Println("Program selesai")
			return

		default:
			fmt.Println("Pilihan salah")
		}
	}
}

func main() {
	menu()
}
